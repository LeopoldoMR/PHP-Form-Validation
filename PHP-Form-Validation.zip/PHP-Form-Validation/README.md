# Formvalidation


## Validates a contact formular by using PHP and HTML code


This project is an example of how a formvalidation could work by using PHP and HTML. Here are some points that the code is complying with:

* Text-Input (username)
* Email-Input
* Password-Input
* Radio-Input (genders)
* Select-Input (countries)
* Checkbox-Input (accepting AGB's)


## How to install this project:

1. clone this project from the repository
2. or download the zip-file
3. copy the code and paste it on your favourite texteditor
4. go to the HTML file, right click and open with live server


## Found a bug?

If you found an issue or would like to submit an improvement to this project, please submit an issue using the issue tab above. 


